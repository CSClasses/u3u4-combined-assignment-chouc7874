// JudyCU3A1Q2
// Judy CHOU
// Starting Date: 2019/05/06
// Modifying Date: 2019/0514
// Ms Harris
// ICS4UI
/* Purpose: Takes an array of unknown size containing ints and doubles, positive and negative numbers. Sort the array into three separate arrays of positive ints, positive doubles and all negatives. The original numbers are entered by the user, then displayed, then split and displayed again with appropriate titles for each. */

// Define different types of empty arrays.
var arr = [Any] ()
var int = [Int]()
var doubles = [Double]()
var negatives = [Any]()

// Output instruction of the program to the user.
print("Hello, user.")
print("The purpose of the porgram is to sort the numbers you enter. The porgam will sort the number you enter into three different lists: positive ints, positive doubles and all negatives.")
print("Let's start the program!")
print("If the answer you enter is wrond, the program will immediately exit.")

// Create a while loop to retakes inputs from the user.
while (true) {
  print("User, Please enter the number.")
  if let answer1 = readLine() {
    // If the input is a integer
    if let int1 = Int(answer1) {
      // Append the input to the array "arr".
       arr.append(int1)
       // Output the array "arr".
       print(arr)
       // If the integer is larger than 0.
       if int1 > 0 {
         /* Append the integer to the positive integer array "int". */
         int.append(int1)
       }
       // If the interger is smaller than 0.
       else if int1 < 0 {
         // Apeend the interger to the array of negatives.
         negatives.append(int1)
       }
    }  
    // If the input is a double.
    else if let double1 = Double(answer1) {
      // Append the double to the array "arr".
      arr.append(double1)
      // Output the any type array "arr".
      print(arr)
      // If the double is positive.
      if double1 > 0.0 {
        /*Append the the double to the array of positive double. */
        doubles.append(double1)
      }
      // Else if the double is negative.
      else if double1 < 0.0 {
        // Append the double to the negatives array.
        negatives.append(double1)
      }
    }
    // Else if input is incorrect.
    else {
      // Exit the program.
      break
    }
  }
  // Output the messages to the user for sorting.
  print("User, do you want to begin sorting?")
  print("If you want to begin sorting, please enter 'yes', lowcases or uppercases all accepted.")
  print("If you do not want to begin sorting, please enter 'no', lowcases or uppercases all accepted.")
  let answer2 = readLine()
  // If the answer is yes.
  if answer2 == "yes" || answer2 == "Yes" || answer2 == "YES" {
    // Output the any array "arr" to the user.
    print("User, there are the numbers you entered.")
    print(arr)
    print("Let's begin sort the numbers!")
    // Output the numbers in different catgerories.
    print("The numbers are sort into different list:")
    print("For the positive integers:")
    /* Output the array "int" for all the postive integers. */
    print(int)
    print("For the positive doubles:")
    /* Output the array "doubles" for all the positive doubles. */
    print(doubles)
    print("For the negatives integers and doubles:")
    /* Output the array "negatives" for all the negative numbers. */
    print(negatives)
    // Else if the answer is "no".
  } else if answer2 == "no" || answer2 == "NO" || answer2 == "No" {
    // Continue for user to enter number.
    continue
  // Else if the answer is not "yes" or "no".
  }else if answer2 != "yes" || answer2 != "no" {
    // Output the messages to the user.
    print("You enter wrong answer.")
    print("You are exiting the program")
    // Exit the program.
    break
  }
}


  




