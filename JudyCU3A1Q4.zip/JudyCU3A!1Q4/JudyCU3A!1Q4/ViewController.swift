// JudyCU3A1Q4
// Judy Chou
// Date: 2019/05/21
/* Purpose: Create a Navigation item with four directional arrows.  When the user chooses up, you should show a picture of something up high.  When the user chooses down, you should show something in that direction.  The left arrow will signify something back and the right arrow, whatever you want. Create a next level down, from the picture then give the user a quiz question relating to the previous picture.  (One picture’s question will be text input, another button or swipe input – you decide on the other 2 what should be done. Make sure the user has a nice exit for your app. */
/* Code Borrowed: https://www.youtube.com/watch?v=5kHTV5VTWOE */

import UIKit

class ViewController: UIViewController {
    // Create connections between the buttons and image
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var upbutton: UIButton!
    @IBOutlet weak var rightbutton: UIButton!
    @IBOutlet weak var downbutton: UIButton!
    @IBOutlet weak var leftbutton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set and output the image.
        image.layer.cornerRadius = 15.0
        image.layer.masksToBounds = true
        
        // Set and output the buttons.
        upbutton.layer.cornerRadius = 7.0
        upbutton.layer.masksToBounds = true
        downbutton.layer.cornerRadius = 7.0
        downbutton.layer.masksToBounds = true
        rightbutton.layer.cornerRadius = 7.0
        rightbutton.layer.masksToBounds = true
        downbutton.layer.cornerRadius = 7.0
        downbutton.layer.masksToBounds = true
        // Do any additional setup after loading the view.
    }


}


