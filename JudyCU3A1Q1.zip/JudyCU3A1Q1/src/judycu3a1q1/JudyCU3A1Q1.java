/* JudyCU3A1Q1
Judy Chou
Ms Harris
ICS4UI
Date: 2019/05/10
Modifying Date: 2019/05/20
Purpose :  Write a program to input a txt file (or xml file) of weather data. 
The data contains a number of header lines you may not want to import. 
Create a nice GUI display for your user allowing them to query the precipitation, wind etc. data by province/city/town and receive summary or detailed data as requested.  
 */
package judycu3a1q1;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.DOMException;
import org.xml.sax.SAXException;

public class JudyCU3A1Q1 {

    public static void main(String argv[]) {
 
      try {
         // Output the messages to the user about the program.
         System.out.println("Hello user, Welecome to the weather program, In this program, you can know the weather in different weather stations in April, 2018.");
         System.out.println("User, the data list below is the weather data in April, 2018.");
         // Create a path for the xml file.
         File xmlfile = new File("C:\\NetBeansApplication\\JudyCU3A1Q1\\src\\judycu3a1q1\\weather.xml");
         // Read the xml file.
         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
         Document doc = dBuilder.parse(xmlfile);
         doc.getDocumentElement().normalize();
         // Create a Scanner object
         Scanner answer1 = new Scanner(System.in);
         // Ask user to input the station name they want to know for the weather.
         System.out.println("Please enter the way you want to search for the weather data.");
         // Read user input.
         String answer = answer1.nextLine();
         System.out.println(doc.getDocumentElement().getNodeName());
         NodeList nList = doc.getElementsByTagName("climatesummary");
         // Getting the data in the xml file
         for (int temp = 0; temp < nList.getLength(); temp++) {
            Node nNode = nList.item(temp);
            System.out.println("\nCurrent Element :" + nNode.getNodeName());
            
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
               Element eElement = (Element) nNode;
     
               // Output messages to the user for the way of searching.
               // If answer is station name.
               // Ask user for the station they want to find.
               // If answer is equal to any station names.
               // Output the weather data matching the station name.
               // Else if the answer does not match any station names
               // Exit the program
               // If answer is identifier ID
               // Ask user for the identifier ID they want to find.
               // If answer is equal to any identifier ID
               // Output the weather data matching the identifier ID.
               
               // Output the name of the station.
               System.out.println("The name od Station : " + eElement.getElementsByTagName("name").item(0).getTextContent());
               // Output the identifer ID od the station.
               System.out.println("The identifer ID is : " + eElement.getElementsByTagName("identifier").item(0).getTextContent());
               // Output the latitude of the station.
               System.out.println("The latitude is: " + eElement.getElementsByTagName("latitude").item(0).getTextContent());
               // Output the longitude of the station.
               System.out.println("The longitude is: " + eElement.getElementsByTagName("longitude").item(0).getTextContent());
               // Output the provience of the station.
               System.out.println("The beloning provience is: " + eElement.getAttribute("code"));
               // Output the average temperature of the station.
               System.out.println("The average temperature is: " + eElement.getElementsByTagName("mean_temperature"));
               // Else if answer does not equal to any Identifer ID or station name
               // Exit the program.
            }
         }
      } catch (IOException | ParserConfigurationException | DOMException | SAXException e) {
      }
   }
}