// JudyCU3A1Q3
// Judy CHOU
// Ms Harris
//
// JudyCU3A1Q1
//Judy CHOU
// Date:  2019/05/10
// Modifying Date: 2019 /05/20
/* Purpose: (Basic – Java)  Make a flowchart then write a program to input a txt file (or xml file) of  weather data.
The data contains a number of header lines you may not want to import.
Create a nice GUI display for your user allowing them to query the precipitation, wind etc. data by province/city/town and receive summary or detailed data as requested.
*/

package com.example.judycu3a1q3;

// import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

// import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
        // Declare  button s for different tip values.
        Button fifteenpercent;
        Button twentypercent;
        Button twentyfivepercent;
        // Declare the textbox for entering value
        EditText editText:
        TextView money;
        // Declare sum as double
        Double sum;
        long finalamount;



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Declare the buutton id and the names
        fifteenpercent = (Button) findViewById(R.id.fifteenpercent);
        twentypercent = (Button) findViewById(R.id.twentypercent);
        twentyfivepercent = (Button) findViewById(R.id.twentyfivepercent);
        editText = (EditText) findViewById(R.id.editText);
        money = (TextView) findViewById(R.id.money);

        finalamount = (long) 1.00;
        fifteenpercent.setOnClickListener(this);
        twentypercent.setOnClickListener(this);
        twentyfivepercent.setOnClickListener(this);
    }
    public void onClick (View view) {
        sum = Double.parseDouble(editText.getText().toString());
        if (view.getId() == fifteenpercent.getId()){
            // Calculate the tip value.
            finalamount = Math.round(sum * .15):
            // Output the tip value.
            money.setText("The tip is" + finalamount.toString());
        }

        if (view.getId() == twentypercent.getId()){
            // Calculate the tip value.
            finalamount = Math.round(sum * .20):
            // Output the tip value.
            money.setText("The tip is" +finalamount.toString());
        }

        if (view.getId() == twentyfivepercent.getId()) {
            // Calculate the tip value.
            finalamount = Math.round(sum * .25):
            // Output the tip value.
            money.setText("The tip is" + finalamount.toString());
        }
    }


}
