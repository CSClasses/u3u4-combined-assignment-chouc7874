// JudyCU3A1Q5
// Judy Chou
// Date: 2019/05/19
// Modifying Date: 2019/05/20
/* Purpose: Impress me with your recursion or I/O or sorting and searching.  You should include, GUI, Images, Listeners, Buttons and other GUI classes.
Write a program that uses two of the above listed elements. */
/* Code Borrowed: https://www.youtube.com/watch?v=vJdn_fdzpS4 */

// Output messages to the user about the game and the rules.
print("Ｈello user, welcome to the program.")
print("In this program, the computer and you will have a compition.")
print("Computers and you will get a random dice point for two rolled.")
print("You will need to against two computer players by yourself.")
print("Please remember, if you enter wrong answer, the program will immediately exit.")
print("User, do you want to start the game?")
let answer = readLine()
while (true) {
    // If user wants to start the game.
    if answer == "yes" {
        // Output message to the user.
        print("User, let's start the game.")
        
        // Declare dice variables for different players.
        let dice1 = Int.random(in: 1 ... 6)
        let dice2 = Int.random(in: 1 ... 6)
        let dice3 = Int.random(in: 1 ... 6)
        
        // Output first time result.
        print("In the first roll, the result is....")
        print("Computer player1, you get \(dice1) points.")
        print("Computer player2, you get \(dice2) points.")
        print("User, you get \(dice3) points.")
        
        // Declare the other dice variables for different players.
        let dice4 = Int.random(in: 1 ... 6)
        let dice5 = Int.random(in: 1 ... 6)
        let dice6 = Int.random(in: 1 ... 6)
        // output second time result.
        print("In the second roll, the result is....")
        print("Computer player1, you get \(dice4) points.")
        print("Computer player2, you get \(dice5) points.")
        print("User, you get \(dice6) points.")
        
        // Calculate the sum for different players
        let sum1 = dice1 + dice4
        let sum2 = dice2 + dice5
        let sum3 = dice3 + dice6
        
        print("The result of the player is...")
        
        // Declare a class to store the name and the sum score of each player.
        class Player {
            let name: String
            let Sum_Score: Int
            init(name: String, Sum_Score: Int) {
                self.name = name
                self.Sum_Score = Sum_Score
            }
        }
        
        // Declare the summary of each player.
        let computerplayer1 = Player(name: "computer player1", Sum_Score: sum1 )
        let computerplayer2 = Player(name: "computer player2", Sum_Score: sum2 )
        let user = Player(name: "user", Sum_Score: sum3 )
        
        var players: [Player] = [computerplayer1, computerplayer2, user]
        
        // Sort the sum score from high to low.
        let Sum_Score = players.sorted(by: { $0.Sum_Score > $1.Sum_Score })
        
        // Output the result by the score and name from high to low.
        for player in Sum_Score {
            print("\(player.name) score = \(player.Sum_Score)")
            players.sort(by: { $0.name < $1.name })
        }
        
        // Exit the program.
        break
    }
    // If the answer is no.
    else if answer == "no" {
        print("You are existing")
        // Exit the program.
        break
    }
    // If answer is not yes or no.
    else {
        print("You enter the wrong answer, you are existing the program.")
        // Exit the program.
        break
    }
}
